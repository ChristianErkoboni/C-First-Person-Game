﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowM : MonoBehaviour {
	public float mouseSensitivity = 100.0f;
	public float clampAngle = 40.0f;

	private float rotY = 0.0f;
	private float rotX = 0.0f;

	public Vector3 rot;
	public float mouseX;
	public float mouseY;

	public Transform Cam;
	public Transform Will;
	// Use this for initialization
	void Start () {
		
		Will = GameObject.Find ("Player").transform;

		rot = transform.localRotation.eulerAngles;
		rotY = rot.y;
		rotX = rot.x;
	}
	
	// Update is called once per frame
	void Update () {
		mouseX = Input.GetAxis ("Mouse X");
		mouseY = -Input.GetAxis ("Mouse Y");

		rotY += mouseX * mouseSensitivity * Time.deltaTime;
		rotX += mouseY * mouseSensitivity * Time.deltaTime;

		rotX = Mathf.Clamp (rotX, -clampAngle, clampAngle);

		Quaternion localRotation = Quaternion.Euler (0, rotY, 0.0f);
		Will.localRotation = Quaternion.Euler (0.0f, rotY + 90, 0.0f);
		transform.position = Will.position + Vector3.up * .50f;
		transform.rotation = localRotation;
	}
}
