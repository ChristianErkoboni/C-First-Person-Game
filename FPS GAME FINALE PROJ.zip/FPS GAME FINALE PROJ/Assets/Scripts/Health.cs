﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class Health : MonoBehaviour {
	public Image health; 
	public float hp = 1f;
	public Image HealthPacks;
	// Use this for initialization
	void Start () {
		health = GameObject.Find ("Health").GetComponent<Image> ();
		HealthPacks = GameObject.Find ("HealthPickups").GetComponent<Image> ();

	}
	
	// Update is called once per frame
	void Update () {
		if (hp <= .2) {
			health.color = Color.red;
		} else if (hp <= .5)
		{
			health.color = Color.yellow;
		}
		if (HealthPacks.fillAmount == 1f)
		{
			if (Input.GetKey("h"))
			{
				hp = 1f;
				health.fillAmount = hp;
				health.color = Color.green;
				HealthPacks.fillAmount = 0;
			}
		}
	}
	void OnCollisionEnter (Collision other)
	{
		if (other.gameObject.name == "Bullet(Clone)") 
		{
			hp -= 0.1f;
			health.fillAmount = hp;
		}
		if (hp <= 0) 
		{
			SceneManager.LoadScene ("ALMOST DONE",LoadSceneMode.Single);
		}
		if (other.gameObject.name == "HealthPack") 
		{
			other.gameObject.SetActive (false);
			HealthPacks.fillAmount += 0.2f;
		}
	}
}
