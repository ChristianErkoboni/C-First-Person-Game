﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EShoot14 : MonoBehaviour {
	public Rigidbody bullet;
	public Rigidbody clone;
	public float Timer = 2;
	public Transform PlayerMan;
	public Transform SpawnPoint;
	// Use this for initialization
	void Start () {
		bullet = Resources.Load ("Prefabs/Bullet", typeof(Rigidbody)) as Rigidbody;
		PlayerMan = GameObject.Find ("LookAtPoint").transform;
		SpawnPoint = GameObject.Find ("enemyBulletSpawnPoint15").transform;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	void OnTriggerStay()
	{
		transform.rotation = Quaternion.Lerp (transform.rotation, PlayerMan.rotation, Time.deltaTime);

		Timer += Time.deltaTime;
		if (Timer >= 2f) 
		{
			clone = Instantiate (bullet,SpawnPoint.position , SpawnPoint.rotation) as Rigidbody;
			Timer = 0;
		}
	}
}
