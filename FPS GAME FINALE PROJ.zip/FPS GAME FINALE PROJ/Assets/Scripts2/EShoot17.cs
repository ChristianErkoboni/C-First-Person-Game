﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EShoot17 : MonoBehaviour {
	public Rigidbody bullet;
	public Rigidbody clone;
	public float Timer;
	public Transform PlayerMan;
	public Transform SpawnPoint;
	// Use this for initialization
	void Start () {
		bullet = Resources.Load ("Prefabs/Bullet", typeof(Rigidbody)) as Rigidbody;
		PlayerMan = GameObject.Find ("LookAtPoint").transform;
		SpawnPoint = GameObject.Find ("enemyBulletSpawnPoint18").transform;
	}
	
	// Update is called once per frame
	void Update () {
		Timer += Time.deltaTime;
	}
	void OnTriggerStay()
	{
		transform.rotation = Quaternion.Lerp (transform.rotation, PlayerMan.rotation, Time.deltaTime);

		if (Timer >= 4f) 
		{
			clone = Instantiate (bullet,SpawnPoint.position , SpawnPoint.rotation) as Rigidbody;
			Timer = 0;
		}
	}
}
